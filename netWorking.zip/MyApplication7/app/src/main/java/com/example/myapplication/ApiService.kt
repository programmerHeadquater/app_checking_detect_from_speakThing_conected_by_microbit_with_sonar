package com.example.myapplication
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {

    @GET("data") // Replace with your actual API endpoint
    fun getData(): Call<ApiResponse>  // This function returns a list of DataModel objects
}
