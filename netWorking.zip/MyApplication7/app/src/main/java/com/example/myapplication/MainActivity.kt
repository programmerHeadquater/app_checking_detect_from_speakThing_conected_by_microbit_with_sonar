package com.example.myapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.ApiResponse
import com.example.myapplication.NetworkUtils.checkInternetPermissionAndConnection
import com.example.myapplication.R
import com.example.myapplication.RetrofitClient
import com.example.myapplication.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var mainActivityBinding: ActivityMainBinding
    var data = "not set"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainActivityBinding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(mainActivityBinding.root)

        val isConnected = checkInternetPermissionAndConnection(this)
        Toast.makeText(this, "Permission" + isConnected.toString(), Toast.LENGTH_SHORT).show()
        mainActivityBinding.StringJson.text = data

        if (isConnected) {
            // Proceed with network operations, like fetching data
            fetchData()
        } else {
            // Show a message to the user or handle no internet case
            showError("No internet connection.")

        }



    }

    private fun fetchData() {
        // Make the API call using Retrofit

        RetrofitClient.apiService.getFeeds().enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful) {
                    // Get the response body which is a raw String
                    val responseData = response.body()
                    if (responseData != null) {
                        val channelName = responseData.channel.name
                        val latestFeedField1 = responseData.feeds.firstOrNull()?.field1 ?: "No data"

                        // Combine the data into a string for display
                        val displayText = "Channel: $channelName\nLatest Distance: $latestFeedField1"
                        mainActivityBinding.StringJson.text = displayText

                    } else {
                        showError("Empty response body.")
                    }
                } else {
                    showError("Error: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                // Handle failure
                showError("Failed to load data: ${t.message}")
                mainActivityBinding.StringJson.text = "${t.message}"
            }
        })
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
