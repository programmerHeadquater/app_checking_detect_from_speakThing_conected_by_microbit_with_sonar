package com.example.myapplication

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface MemberApiService {

    // GET request: Fetch member details by ID


    @GET("channels/2738584/fields/1.json?results=2")
    fun getFeeds(): Call<ApiResponse>

    @GET("update?api_key=CPWKLHF7PGPOLXQA&field1=88")
    fun writeDate(): Call<ApiService>

    // POST request: Add a new member
//    @POST("members")
//    fun addMember(@Body member: Member): Call<MemberResponse>

    // PUT request: Update an existing member
//    @PUT("members/{id}")
//    fun updateMember(@Path("id") memberId: String, @Body member: Member): Call<MemberResponse>

    // DELETE request: Delete a member by ID
//    @DELETE("members/{id}")
//    fun deleteMember(@Path("id") memberId: String): Call<MemberResponse>
}
